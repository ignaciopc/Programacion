/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea21herenciaejercicio2;

/**
 *
 * @author ignac
 */
public class punto {
    private int x;
    private int y;

    public punto(int x, int y){
        this.x = x;
        this.y = y;
    }
    public int getXp() {
        return x;
    }

    public void setXp(int x) {
        this.x = x;
    }

    public int getYp() {
        return y;
    }

    public void setYp(int y) {
        this.y = y;
    }
    
}
