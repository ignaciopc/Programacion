/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea22excepciones;

/**
 *
 * @author ignac
 */
public class dorsalNegativoExcepcion  extends Exception{
    public dorsalNegativoExcepcion(){
        System.out.println("No pueden haber dorsales negativos");
    }
}
